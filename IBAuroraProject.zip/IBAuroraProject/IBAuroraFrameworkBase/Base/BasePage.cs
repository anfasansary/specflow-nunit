﻿using OpenQA.Selenium.Support.PageObjects;

namespace IBAuroraAutomation.Base
{
    public abstract class BasePage : Base
    {
        public BasePage(ParallelConfig parellelConfig) : base(parellelConfig)
        {
        }
    }
}
