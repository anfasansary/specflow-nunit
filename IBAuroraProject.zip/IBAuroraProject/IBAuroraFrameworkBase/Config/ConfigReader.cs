﻿using System;
using IBAuroraAutomation.Base;
using IBAuroraAutomation.ConfigElement;

namespace IBAuroraAutomation.Config
{
    public class ConfigReader
    {
        public static void SetFrameworkSettings()
        {
            Settings.AUT = TestConfiguration.IBAuroraSettings.TestSettings["staging"].AUT;
            //Settings.BuildName = buildname.Value.ToString();
            Settings.TestType = TestConfiguration.IBAuroraSettings.TestSettings["staging"].TestType;
            //Settings.IsLog = EATestConfiguration.IBAuroraSettings.TestSettings["staging"].IsLog;
            //Settings.IsReporting = EATestConfiguration.IBAuroraSettings.TestSettings["staging"].IsReadOnly;
            //Settings.LogPath = EATestConfiguration.IBAuroraSettings.TestSettings["staging"].LogPath;
            //Settings.AppConnectionString = EATestConfiguration.IBAuroraSettings.TestSettings["staging"].AUTDBConnectionString;
            Settings.BrowserType = (BrowserType)Enum.Parse(typeof(BrowserType), TestConfiguration.IBAuroraSettings.TestSettings["staging"].Browser);
        }

    }
}
