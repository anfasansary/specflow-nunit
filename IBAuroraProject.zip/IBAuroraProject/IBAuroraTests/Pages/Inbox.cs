﻿using IBAuroraAutomation.Base;
using IBAuroraAutomation.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBAuroraTests.Pages
{
    public class Inbox : BasePage
    {
        public Inbox(ParallelConfig parellelConfig) : base(parellelConfig)
        {
        }

        public void PageLoad()
        {
            _parallelConfig.Driver.WaitForPageLoaded();
            Console.WriteLine("Reached Inbox Page");
        }
    }
}
