﻿using IBAuroraAutomation.Base;
using IBAuroraAutomation.Extensions;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace IBAuroraTests.Pages
{
    class Dashboard : BasePage
    {
        public Dashboard(ParallelConfig parellelConfig) : base(parellelConfig)
        {
        }

        /// <summary>
        /// Web element Initializing
        /// </summary>
        private string validationmessage = "div.error-messages > div";
        IWebElement validationMsg => _parallelConfig.Driver.FindElement(By.CssSelector(validationmessage));

        private string usermenuitem = "userMenuItem";
        IWebElement userMenu => _parallelConfig.Driver.FindElement(By.Id(usermenuitem));

        private string fullname = "div.user-details > h4";
        IWebElement fullName => _parallelConfig.Driver.FindElement(By.CssSelector(fullname));

        private string logout = "logout-button";
        IWebElement logOut => _parallelConfig.Driver.FindElement(By.Id(logout));

        private string logoutconfirm = "button[title = 'Yes']";
        IWebElement logoutConfirm => _parallelConfig.Driver.FindElement(By.CssSelector(logoutconfirm));

        private string inboxmenu = "Inbox";
        IWebElement inboxMenu => _parallelConfig.Driver.FindElement(By.Id(inboxmenu));


        /// <summary>
        /// Actions performed against web elements are implemented here
        /// </summary>
        public void PageLoad()
        {
            _parallelConfig.Driver.WaitForPageLoaded();
        }

        public string GetLoginValidationMessage()
        {
            Thread.Sleep(2000);
            Console.WriteLine(validationMsg.GetLinkText());
            return validationMsg.GetLinkText();
        }

        public void ClickUserMenu()
        {
            _parallelConfig.Driver.WaitForElement(usermenuitem, "Id");
            userMenu.Click();
        }

        public string VerifyUserName()
        {
            _parallelConfig.Driver.WaitForElement(fullname, "CssSelector");
            return fullName.GetLinkText();
        }

        public Inbox ClickInboxMenu()
        {
            _parallelConfig.Driver.WaitForElement(inboxmenu, "Id");
            inboxMenu.Click();
            return new Inbox(_parallelConfig);
        }

        public LoginPage ClickLogout()
        {
            _parallelConfig.Driver.WaitForElement(logout, "Id");
            logOut.Click();
            _parallelConfig.Driver.WaitForElement(logoutconfirm, "CssSelector");
            logoutConfirm.Click();
            return new LoginPage(_parallelConfig);
        }
    }
}
