﻿using IBAuroraAutomation.Base;
using IBAuroraAutomation.Extensions;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBAuroraTests.Pages
{
    class LoginPage : BasePage
    {
        public LoginPage(ParallelConfig parallelConfig) : base(parallelConfig) { }

        /// <summary>
        /// Web element Initializing
        /// </summary>
        private string usernamefield = "usernameBox";
        IWebElement userNameField => _parallelConfig.Driver.FindElement(By.Id(usernamefield));

        private string passwordfield = "passwordBox";
        IWebElement passwordField => _parallelConfig.Driver.FindElement(By.Id(passwordfield));

        private string buttonmarking = "btnMarking";
        IWebElement buttonMarking => _parallelConfig.Driver.FindElement(By.Id(buttonmarking));

        /// <summary>
        /// Actions performed against web elements are implemented here
        /// </summary>
        public void PageLoad()
        {
            _parallelConfig.Driver.WaitForPageLoaded();
        }

        public void EnterUserDetails(string username, string password)
        {
            _parallelConfig.Driver.WaitForElement(usernamefield, "id");
            userNameField.SendKeys(username);
            _parallelConfig.Driver.WaitForElement(passwordfield, "id");
            passwordField.SendKeys(password);
        }

        public Dashboard ClickSubmit()
        {
            _parallelConfig.Driver.WaitForElement(buttonmarking, "id");
            buttonMarking.Click();
            return new Dashboard(_parallelConfig);
        }
    }
}
