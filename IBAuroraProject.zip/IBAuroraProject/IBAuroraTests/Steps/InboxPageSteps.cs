﻿using IBAuroraTests.Pages;
using IBAuroraAutomation.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace IBAuroraTests.Steps
{
    [Binding]
    class InboxPageSteps : BaseStep
    {
        //Context injection
        private readonly ParallelConfig _parallelConfig;

        public InboxPageSteps(ParallelConfig parallelConfig) : base(parallelConfig)
        {
            _parallelConfig = parallelConfig;
        }

        [Then(@"I have navigated to inbox page")]
        public void ThenIHaveNavigatedToInboxPage()
        {
            _parallelConfig.CurrentPage.As<Inbox>().PageLoad();
        }
    }
}
