﻿using IBAuroraTests.Pages;
using IBAuroraAutomation.Base;
using IBAuroraAutomation.Config;
using TechTalk.SpecFlow;

namespace EAEmployeeTest.Steps
{
    [Binding]
    internal class ExtendedSteps : BaseStep
    {
        //Context injection
        private readonly ParallelConfig _parallelConfig;

        public ExtendedSteps(ParallelConfig parallelConfig) : base(parallelConfig)
        {
            _parallelConfig = parallelConfig;
        }

        public void NavigateSite()
        {
            _parallelConfig.Driver.Navigate().GoToUrl(Settings.AUT);
            //LogHelpers.Write("Opened the browser !!!");
        }

        [Given(@"I have navigated to the application")]
        public void GivenIHaveNavigatedToTheApplication()
        {
            NavigateSite();
            _parallelConfig.CurrentPage = new LoginPage(_parallelConfig);
        }

        [Then(@"I click (.*) button")]
        public void ThenIClickButton(string buttonName)
        {
            if (buttonName == "login")
            {
                _parallelConfig.CurrentPage = _parallelConfig.CurrentPage.As<LoginPage>().ClickSubmit();
                _parallelConfig.CurrentPage.As<Dashboard>().PageLoad();
            }
            else if (buttonName == "logout")
            {
                _parallelConfig.CurrentPage = _parallelConfig.CurrentPage.As<Dashboard>().ClickLogout();
            }
        }

        [Then(@"I click (.*) link")]
        public void ThenIClickLink(string linkName)
        {
            if (linkName == "userMenu")
                _parallelConfig.CurrentPage.As<Dashboard>().ClickUserMenu();
            else if (linkName == "inbox")
                _parallelConfig.CurrentPage = _parallelConfig.CurrentPage.As<Dashboard>().ClickInboxMenu();
        }
    }
}
