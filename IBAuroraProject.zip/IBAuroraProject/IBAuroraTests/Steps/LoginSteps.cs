﻿using IBAuroraAutomation.Base;
using IBAuroraTests.Pages;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using NUnit.Framework;

namespace IBAuroraTests.Steps
{
    [Binding]
    public class LoginSteps : BaseStep
    {
        //Context injection
        private readonly ParallelConfig _parallelConfig;

        public LoginSteps(ParallelConfig parallelConfig) : base(parallelConfig)
        {
            _parallelConfig = parallelConfig;
        }

        [Given(@"I see application opened")]
        public void GivenISeeApplicationOpened()
        {
            _parallelConfig.CurrentPage.As<LoginPage>().PageLoad();
        }

        [When(@"I enter UserName and Password")]
        public void WhenIEnterUserNameAndPassword(Table table)
        {
            dynamic data = table.CreateDynamicInstance();
            _parallelConfig.CurrentPage.As<LoginPage>().EnterUserDetails(data.UserName, data.Password);
        }

        [Then(@"I should verify the validation message")]
        public void ThenIShouldVerifyTheValidationMessage(Table table)
        {
            dynamic data = table.CreateDynamicInstance();
            Assert.AreEqual(data.ValidationMessage, _parallelConfig.CurrentPage.As<Dashboard>().GetLoginValidationMessage(), "Validation Message Mismatched");
            //Assert.That(data.ValidationMessage, Is.EqualTo(_parallelConfig.CurrentPage.As<Dashboard>().GetLoginValidationMessage()));
        }

        [Then(@"I should see the username in User Menu")]
        public void ThenIShouldSeeTheUsername(Table table)
        {
            dynamic data = table.CreateDynamicInstance();
            Assert.AreEqual(data.ContactName, _parallelConfig.CurrentPage.As<Dashboard>().VerifyUserName(), "Contact Name Mismatched");
        }
    }
}
